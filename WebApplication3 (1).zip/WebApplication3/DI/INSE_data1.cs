﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Model;

namespace WebApplication3.DI
{
    public interface INSE_data1
    {
        Task<string> ADDNSE(NSE_data1 nSE_data1);
        Task<string> UPDATENSE(NSE_data1 nSE_data1);
        Task<string> DELETENSE(NSE_data1 nSE_data1);
    }
}
