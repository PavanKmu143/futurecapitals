﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.DataAccessLayer;
using WebApplication3.Model;

namespace WebApplication3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NSEController : ControllerBase
    {
        private readonly Db1Context _dataContext;
        public NSEController(Db1Context dataContext)
        {
            _dataContext = dataContext;
        }
        [HttpGet]
        [Route("Securities")]
        public IActionResult GetSecurities()
        {
            var info = _dataContext.NSE_Data1.ToList();
            return Ok(info);
        }
        [HttpPost]//Add securities 
        [Route("Add")]
        public IActionResult AddNSE(NSE_data1 nSE_data1)
        {
            _dataContext.NSE_Data1.Add(nSE_data1);
            _dataContext.SaveChanges();
            return Ok(nSE_data1.ISIN);
        }
        [HttpPut]//Update securities
        [Route("Update")]
        public IActionResult UpdateNSE(NSE_data1 nSE_Export)
        {
            _dataContext.Update(nSE_Export);
            _dataContext.SaveChanges();
            return NoContent();
        }
        [HttpDelete]//Delete securities
        public IActionResult DeleteNSE(string isin)
        {
            var del = _dataContext.NSE_Data1.Where(x => x.ISIN == isin).FirstOrDefault();
            if (del == null)
            {
                return NotFound();
            }
            _dataContext.NSE_Data1.Remove(del);
            _dataContext.SaveChanges();
            return NoContent();
        }

        [HttpGet]//Get by ISIN
        [Route("ISIN")]
        public async Task<ActionResult<NSE_data1>> ISIN(string isin)
        {
            if (isin == null)
            {
                return NotFound();
            }
            var ss = await _dataContext.NSE_Data1.FirstOrDefaultAsync(x => x.ISIN == isin);
            if (ss == null)
            {
                return NotFound();
            }
            return Ok(ss);
        }
        [HttpGet]//Get by SYMBOL
        [Route("SYMBOL")]
        public async Task<ActionResult<NSE_data1>> SYMBOL(string symbol)
        {
            if (symbol == null)
            {
                return NotFound();
            }
            var ss = await _dataContext.NSE_Data1.FirstOrDefaultAsync(x => x.SYMBOL == symbol);
            if (ss == null)
            {
                return NotFound();
            }
            return Ok(ss);
        }
        [HttpGet]//Get by NAME_OF_COMPANY
        [Route("NAME_OF_COMPANY")]
        public async Task<ActionResult<NSE_data1>> NAME_OF_COMPANY(string nAME_OF_COMPANY)
        {
            if (nAME_OF_COMPANY == null)
            {
                return NotFound();
            }
            var ss = await _dataContext.NSE_Data1.FirstOrDefaultAsync(x => x.NAME_OF_COMPANY == nAME_OF_COMPANY);
            if (ss == null)
            {
                return NotFound();
            }
            return Ok(ss);
        }/*
        [HttpGet("{isin}")]
        [Route("DetailsWithISIN")]
        public async Task<ActionResult<NSE_Export>> GetDetails(int isin)
        {
            var details = await _dbContext.NSE_Export.FindAsync(isin);

 

            if (details == null)
            {
                return NotFound();
            }
            return details;
        }*/
    }
}
    