﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.CommonLayer.Model;
using WebApplication3.DataAccessLayer;
using WebApplication3.Model;

namespace WebApplication3.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class UploadFileController : ControllerBase
    {
        public readonly IUploadFileDL _uploadFileDL;
        public UploadFileController(IUploadFileDL uploadFileDL)
        {
            _uploadFileDL = uploadFileDL;
        }
        [HttpPost]
        [Route("UploadExcelFile")]
        public async Task<IActionResult> UploadExcelFile([FromForm]UploadExcelFileRequest request)
        {
            UploadExcelFileResponse response = new UploadExcelFileResponse();
            string Path = "UploadFileFolder/" + request.File.FileName;
            try
            {
                using(FileStream stream=new FileStream(Path, FileMode.CreateNew))
                {
                    await request.File.CopyToAsync(stream);
                }
                response = await _uploadFileDL.UploadExcelFile(request, Path);
                string[] Files = Directory.GetFiles("UploadFileFolder/");
                foreach(string file in Files)
                {
                    System.IO.File.Delete(file);
                    Console.WriteLine($"{file} is deleted");
                }

            }catch(Exception ex)
            {
                response.IsSuccessful = false;
                response.Message = ex.Message;
            }
            return Ok(response);

        }
        [HttpPost]
        [Route("UploadCsvFile")]
        public async Task<IActionResult> UploadCsvFile([FromForm] UploadCsvFileRequest request)
        {
            UploadCsvFileResponse response = new UploadCsvFileResponse();
            string Path = "UploadFileFolder/" + request.File.FileName;
            try
            {
                using (FileStream stream = new FileStream(Path, FileMode.CreateNew))
                {
                    await request.File.CopyToAsync(stream);
                }
                response = await _uploadFileDL.UploadCsvFile(request, Path);
                string[] Files = Directory.GetFiles("UploadFileFolder/");
                foreach (string file in Files)
                {
                    System.IO.File.Delete(file);
                    Console.WriteLine($"{file} is deleted.");
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            return Ok(response);

        }

        [HttpPost]
        [Route("ReadRecord")]
        public async Task<IActionResult> ReadRecord(ReadRecordRequest request)
        {
            ReadRecordResponse response = new ReadRecordResponse();
            try
            {
                response = await _uploadFileDL.ReadRecord(request);
            }catch(Exception ex)
            {
                response.IsSuccess = false;
                response.Message=ex.Message;
            }
            return Ok(response);
        }
        [HttpDelete]
        [Route("DeleteRecord")]
        public async Task<IActionResult> DeleteRecord(DeleteRecordRequest request)
        {
            DeleteRecordResponse response = new DeleteRecordResponse();
            try
            {
                response = await _uploadFileDL.DeleteRecord(request);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            return Ok(response);
        }

    }
}
