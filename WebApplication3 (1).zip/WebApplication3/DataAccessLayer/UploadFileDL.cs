﻿
using ExcelDataReader;
using LumenWorks.Framework.IO.Csv;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System; 
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.CommonLayer.Model;
using WebApplication3.Model;

namespace WebApplication3.DataAccessLayer
{
    public class UploadFileDL : IUploadFileDL
    {
        public readonly IConfiguration _configuration;
        public readonly MySqlConnection _mySqlConnection;
        public UploadFileDL(IConfiguration configuration)
        {
            _configuration = configuration;
            _mySqlConnection = new MySqlConnection(_configuration["ConnectionStrings:Conn"]);

        }

        public async Task<DeleteRecordResponse> DeleteRecord(DeleteRecordRequest request)
        {
            DeleteRecordResponse response = new DeleteRecordResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {
                if (_mySqlConnection.State != ConnectionState.Open)
                {
                    await _mySqlConnection.OpenAsync();
                }
                string SqlQuery = @"DELETE FROM NSE_data1.usm1 WHERE ISIN=@ISIN";
                using(MySqlCommand sqlCommand=new MySqlCommand(SqlQuery,_mySqlConnection))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.CommandTimeout = 100;
                    sqlCommand.Parameters.AddWithValue("ISIN", request.ISIN);
                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        response.IsSuccess = false;
                        response.Message = "Query Not Executed";
                        return response;
                    }
                }
            }
            catch(Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _mySqlConnection.CloseAsync();
                await _mySqlConnection.DisposeAsync();

            }
            return response;
        }

        public async Task<ReadRecordResponse> ReadRecord(ReadRecordRequest request)
        {
            ReadRecordResponse response = new ReadRecordResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {
                if (_mySqlConnection.State != ConnectionState.Open)
                {
                    await _mySqlConnection.OpenAsync();
                }
                string SqlQuery = @"SELECT * FROM usm1.NSE_data1 LIMIT @Offset,@RecordPerPage";
                using (MySqlCommand sqlCommand = new MySqlCommand(SqlQuery,_mySqlConnection))
                {
                    int Offset = (request.PageNumber - 1) * request.NumberOfRecordPerPage;
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.CommandTimeout = 100;
                    sqlCommand.Parameters.AddWithValue("@Offset",Offset);
                    sqlCommand.Parameters.AddWithValue("@RecordPerPage",request.NumberOfRecordPerPage);
                    using (DbDataReader sqlDataReader=await sqlCommand.ExecuteReaderAsync())
                    {
                        if (sqlDataReader.HasRows)
                        {
                            response.data = new List<ReadRecord>();
                            while(await sqlDataReader.ReadAsync())
                            {
                                ReadRecord getdata = new ReadRecord();
                                getdata.SYMBOL = sqlDataReader["SYMBOL"] != DBNull.Value ? Convert.ToString(sqlDataReader["SYMBOL"]):"-1";
                                getdata.NAME_OF_COMPANY = sqlDataReader["NAME_OF_COMPANY"] != DBNull.Value ? Convert.ToString(sqlDataReader["NAME_OF_COMPANY"]) : "-1";
                                getdata.SERIES = sqlDataReader["SERIES"] != DBNull.Value ? Convert.ToString(sqlDataReader["SERIES"]) : "-1";
                                getdata.DATE_OF_LISTING = sqlDataReader["DATE_OF_LISTING"] != DBNull.Value ? Convert.ToString(sqlDataReader["DATE_OF_LISTING"]) : "-1";
                                getdata.PAID_UP_VALUE = sqlDataReader["PAID_UP_VALUE"] != DBNull.Value ? Convert.ToString(sqlDataReader["PAID_UP_VALUE"]) : "-1";
                                getdata.MARKET_LOT = sqlDataReader["MARKET_LOT"] != DBNull.Value ? Convert.ToString(sqlDataReader["MARKET_LOT"]) : "-1";
                                getdata.ISIN = sqlDataReader["ISIN"] != DBNull.Value ? Convert.ToString(sqlDataReader["ISIN"]) : "-1";
                                getdata.FACE_VALUE = sqlDataReader["FACE_VALUE"] != DBNull.Value ? Convert.ToString(sqlDataReader["FACE_VALUE"]) : "-1";
                                getdata.SECTOR = sqlDataReader["SECTOR"] != DBNull.Value ? Convert.ToString(sqlDataReader["SECTOR"]) : "-1";
                                getdata.INDUSTRY = sqlDataReader["INDUSTRY"] != DBNull.Value ? Convert.ToString(sqlDataReader["INDUSTRY"]) : "-1";
                                getdata.EXCHANGE = sqlDataReader["EXCHANGE"] != DBNull.Value ? Convert.ToString(sqlDataReader["EXCHANGE"]) : "-1";
                                getdata.CURRENCY = sqlDataReader["CURRENCY"] != DBNull.Value ? Convert.ToString(sqlDataReader["CURRENCY"]) : "-1";
                                
                                response.data.Add(getdata);
                            }

                        }
                        else
                        {
                            response.Message = "Record Not Found";
                        }
                    }
                }
                
            }catch(Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _mySqlConnection.CloseAsync();
                await _mySqlConnection.DisposeAsync();
            }
            return response;
        }

        public async Task<UploadCsvFileResponse> UploadCsvFile(UploadCsvFileRequest request,string Path)
        {
            UploadCsvFileResponse response = new UploadCsvFileResponse();
            List<ExcelBulkUploadParameter> parameters = new List<ExcelBulkUploadParameter>();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {
                if (request.File.FileName.ToLower().Contains(".csv"))
                {
                    DataTable value = new DataTable();
                    using (var csvReader = new CsvReader(new StreamReader(File.OpenRead(Path)), true))
                    {
                        value.Load(csvReader);
                    }
                    for (int i = 0; i < value.Rows.Count; i++)
                    {
                        ExcelBulkUploadParameter rows = new ExcelBulkUploadParameter();
                        rows.SYMBOL = value.Rows[i][0] != null ? Convert.ToString(value.Rows[i][0]) : "-1";
                        rows.NAME_OF_COMPANY = value.Rows[i][1] != null ? Convert.ToString(value.Rows[i][1]) : "-1";
                        rows.SERIES = value.Rows[i][2] != null ? Convert.ToString(value.Rows[i][2]) : "-1";
                        rows.DATE_OF_LISTING = value.Rows[i][3] != null ? Convert.ToString(value.Rows[i][3]) : "-1";
                        rows.PAID_UP_VALUE = value.Rows[i][4] != null ? Convert.ToString(value.Rows[i][4]) : "-1";
                        rows.MARKET_LOT = value.Rows[i][5] != null ? Convert.ToString(value.Rows[i][5]) : "-1";
                        rows.ISIN = value.Rows[i][6] != null ? Convert.ToString(value.Rows[i][6]) : "-1";
                        rows.FACE_VALUE = value.Rows[i][7] != null ? Convert.ToString(value.Rows[i][7]) : "-1";
                        rows.SECTOR = value.Rows[i][8] != null ? Convert.ToString(value.Rows[i][8]) : "-1";
                        rows.INDUSTRY = value.Rows[i][9] != null ? Convert.ToString(value.Rows[i][9]) : "-1";
                        rows.EXCHANGE = value.Rows[i][10] != null ? Convert.ToString(value.Rows[i][10]) : "-1";
                        rows.CURRENCY = value.Rows[i][11] != null ? Convert.ToString(value.Rows[i][11]) : "-1";
                        parameters.Add(rows);
                    }

                }
                else
                {
                    response.IsSuccess = false;
                    response.Message = "Invalid File";
                    return response;
                }
                if (parameters.Count > 0)
                {
                    if (_mySqlConnection.State != ConnectionState.Open)
                    {
                        await _mySqlConnection.OpenAsync();
                    }
                    string SqlQuery = @"INSERT INTO usm1.NSE_data1
                                      (SYMBOL,NAME_OF_COMPANY,SERIES,DATE_OF_LISTING,PAID_UP_VALUE,MARKET_LOT,ISIN,FACE_VALUE,SECTOR,INDUSTRY,EXCHANGE,CURRENCY) VALUES
                                      (@SYMBOL,@NAME_OF_COMPANY,@SERIES,@DATE_OF_LISTING,@PAID_UP_VALUE,@MARKET_LOT,@ISIN,@FACE_VALUE,@SECTOR,@INDUSTRY,@EXCHANGE,@CURRENCY)";
                    foreach (ExcelBulkUploadParameter rows in parameters)
                    {
                        using (MySqlCommand sqlCommand = new MySqlCommand(SqlQuery, _mySqlConnection))
                        {
                            sqlCommand.CommandType = CommandType.Text;
                            sqlCommand.CommandTimeout = 180;
                            sqlCommand.Parameters.AddWithValue("@SYMBOL", rows.SYMBOL);
                            sqlCommand.Parameters.AddWithValue("@NAME_OF_COMPANY", rows.NAME_OF_COMPANY);
                            sqlCommand.Parameters.AddWithValue("@SERIES", rows.SERIES);
                            sqlCommand.Parameters.AddWithValue("@DATE_OF_LISTING", rows.DATE_OF_LISTING);
                            sqlCommand.Parameters.AddWithValue("@PAID_UP_VALUE", rows.PAID_UP_VALUE);
                            sqlCommand.Parameters.AddWithValue("@MARKET_LOT", rows.MARKET_LOT);
                            sqlCommand.Parameters.AddWithValue("@ISIN", rows.ISIN);
                            sqlCommand.Parameters.AddWithValue("@FACE_VALUE", rows.FACE_VALUE);
                            sqlCommand.Parameters.AddWithValue("@SECTOR", rows.SECTOR);
                            sqlCommand.Parameters.AddWithValue("@INDUSTRY", rows.INDUSTRY);
                            sqlCommand.Parameters.AddWithValue("@EXCHANGE", rows.EXCHANGE);
                            sqlCommand.Parameters.AddWithValue("@CURRENCY", rows.CURRENCY);
                            int Status = await sqlCommand.ExecuteNonQueryAsync();
                            if (Status <= 0)
                            {
                                response.IsSuccess = false;
                                response.Message = "Query Not Executed";
                                return response;
                            }
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;

            }
            finally
            {
                await _mySqlConnection.CloseAsync();
                await _mySqlConnection.DisposeAsync();
            }
            return response;
        }

        public async Task<UploadExcelFileResponse> UploadExcelFile(UploadExcelFileRequest request,string Path)
        {
            UploadExcelFileResponse response = new UploadExcelFileResponse();
            List<ExcelBulkUploadParameter> Parameter = new List<ExcelBulkUploadParameter>();
            response.IsSuccessful = true;
            response.Message = "Successful";
            try
            {
                if (_mySqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _mySqlConnection.OpenAsync();
                }
                if (request.File.FileName.ToLower().Contains(".xlsx"))
                {
                    FileStream stream = new FileStream(Path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
                    IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);
                    DataSet dataset = reader.AsDataSet(
                        new ExcelDataSetConfiguration()
                        {
                            UseColumnDataType = false,
                            ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                            {
                                UseHeaderRow = true
                            }
                        });
                    for (int i = 0; i < dataset.Tables[0].Rows.Count; i++)
                    {
                        ExcelBulkUploadParameter rows = new ExcelBulkUploadParameter();
                        rows.SYMBOL = dataset.Tables[0].Rows[i].ItemArray[0] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.NAME_OF_COMPANY = dataset.Tables[0].Rows[i].ItemArray[1] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]):"-1";
                        rows.SERIES = dataset.Tables[0].Rows[i].ItemArray[2] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.DATE_OF_LISTING = dataset.Tables[0].Rows[i].ItemArray[3] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.PAID_UP_VALUE = dataset.Tables[0].Rows[i].ItemArray[4] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.MARKET_LOT = dataset.Tables[0].Rows[i].ItemArray[5] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.ISIN = dataset.Tables[0].Rows[i].ItemArray[6] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.FACE_VALUE = dataset.Tables[0].Rows[i].ItemArray[7] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.SECTOR = dataset.Tables[0].Rows[i].ItemArray[8] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.INDUSTRY = dataset.Tables[0].Rows[i].ItemArray[9] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.EXCHANGE = dataset.Tables[0].Rows[i].ItemArray[10] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.CURRENCY = dataset.Tables[0].Rows[i].ItemArray[11] != null ? Convert.ToString(dataset.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        Parameter.Add(rows);
                    }
                    stream.Close();
                    if (Parameter.Count > 0)
                    {
                        string SqlQuery = @"INSERT INTO usm1";
                        foreach(ExcelBulkUploadParameter rows in Parameter)
                        {
                            using(MySqlCommand sqlCommand=new MySqlCommand())
                            {
                                sqlCommand.CommandType = CommandType.Text;
                                sqlCommand.CommandTimeout = 100;
                                sqlCommand.Parameters.AddWithValue("@SYMBOL", rows.SYMBOL);
                                sqlCommand.Parameters.AddWithValue("@NAME_OF_COMPANY", rows.NAME_OF_COMPANY);
                                sqlCommand.Parameters.AddWithValue("@SERIES", rows.SERIES);
                                sqlCommand.Parameters.AddWithValue("@DATE_OF_LISTING", rows.DATE_OF_LISTING);
                                sqlCommand.Parameters.AddWithValue("@PAID_UP_VALUE", rows.PAID_UP_VALUE);
                                sqlCommand.Parameters.AddWithValue("@MARKET_LOT", rows.MARKET_LOT);
                                sqlCommand.Parameters.AddWithValue("@ISIN", rows.ISIN);
                                sqlCommand.Parameters.AddWithValue("@FACE_VALUE", rows.FACE_VALUE);
                                sqlCommand.Parameters.AddWithValue("@SECTOR", rows.SECTOR);
                                sqlCommand.Parameters.AddWithValue("@INDUSTRY", rows.INDUSTRY);
                                sqlCommand.Parameters.AddWithValue("@EXCHANGE", rows.EXCHANGE);
                                sqlCommand.Parameters.AddWithValue("@CURRENCY", rows.CURRENCY);
                                int status = await sqlCommand.ExecuteNonQueryAsync();
                                if (status <= 0)
                                {
                                    response.IsSuccessful = false;
                                    response.Message = "Query Not Executed";
                                    return response;
                                }
                            }
                        }
                    }


                }
                else
                {
                    response.IsSuccessful = false;
                    response.Message = "InCorrect File";
                    return response;
                }
            }
            catch (Exception ex)
            {
                response.IsSuccessful = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _mySqlConnection.CloseAsync();
                await _mySqlConnection.DisposeAsync();                
            }
            return response;
        }
    }
}
