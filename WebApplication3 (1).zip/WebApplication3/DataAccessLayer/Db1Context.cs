﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Model;

namespace WebApplication3.DataAccessLayer
{
    public class Db1Context : DbContext
    {
        public Db1Context(DbContextOptions<Db1Context> options) : base(options) { }
        public DbSet<NSE_data1>NSE_Data1{get;set;}
    }
}
