﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication3.CommonLayer.Model
{
    public class ReadRecordRequest
    {
        public int PageNumber { get; set; }
        public int NumberOfRecordPerPage { get; set; }
    }
    public class ReadRecordResponse
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public List<ReadRecord> data { get; set; }
    }
    public class ReadRecord
    {
        public string SYMBOL { get; set; }
        public string NAME_OF_COMPANY { get; set; }
        public string SERIES { get; set; }
        public string DATE_OF_LISTING { get; set; }
        public string PAID_UP_VALUE { get; set; }
        public string MARKET_LOT { get; set; }
        [Key]
        public string ISIN { get; set; }
        public string FACE_VALUE { get; set; }
        public string SECTOR { get; set; }
        public string INDUSTRY { get; set; }
        public string EXCHANGE { get; set; }
        public string CURRENCY { get; set; }
    }
}
